import VideoPlayer from "./video-player";
import AttendanceButton from "./attendance-button";
import LoginButton from "./login-button";
import GameHighlights from "@/components/game/GameHighlights";
import GameRanking from "@/components/game/GameRanking";
import ShortsSlider from "@/components/home/ShortsSlider";
import db from "@/lib/db";
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import DailyQuestCard from "@/components/home/DailyQuestCard";
import BroadcastMissionCard from "@/components/home/BroadcastMissionCard";
import NotificationBell from "@/components/NotificationBell";

async function safeQuery<T = any>(query: string, params: any[] = []): Promise<T[]> {
  try {
    const [rows]: any = await db.query(query, params);
    return rows || [];
  } catch (error) {
    console.error(error);
    return [];
  }
}

async function getYoutubeVideo() {
  try {
    const baseUrl = process.env.NEXTAUTH_URL || "https://www.xn--9l5bo4l.com";
    const res = await fetch(`${baseUrl}/api/youtube`, { cache: "no-store" });

    if (!res.ok) throw new Error("youtube api failed");

    return res.json();
  } catch {
    return {
      isLive: false,
      title: "유튜브 영상을 불러오는 중 문제가 발생했습니다.",
      videos: [],
      shorts: [],
      liveStatus: "off",
      liveForce: "auto",
    };
  }
}

async function getCurrentUser(email?: string | null) {
  if (!email) return null;

  const rows = await safeQuery(
    `
    SELECT id, email, nickname, role, dotori
    FROM users
    WHERE email = ?
    LIMIT 1
    `,
    [email]
  );

  return rows[0] || null;
}

async function getSiteSettings() {
  const rows = await safeQuery(`
    SELECT site_logo, live_status, live_force
    FROM site_settings
    LIMIT 1
  `);

  return {
    siteLogo: rows[0]?.site_logo || null,
    liveStatus: rows[0]?.live_status || "off",
    liveForce: rows[0]?.live_force || "auto",
  };
}

function formatSeasonRemaining(value: unknown) {
  const text = String(value || "").slice(0, 19).replace(" ", "T");
  if (!text) return "-";
  const end = new Date(`${text}+09:00`).getTime();
  const diff = Math.max(0, end - Date.now());
  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const minutes = Math.floor((diff % 3600000) / 60000);
  if (days > 0) return `${days}일 ${hours}시간`;
  if (hours > 0) return `${hours}시간 ${minutes}분`;
  return `${minutes}분`;
}

async function getMainData() {
  const [
    mainPostRows,
    noticePosts,
    recentPosts,
    bestPosts,
    recentComments,
    shopItems,
    dotoriRanking,
    stockPreview,
    stockSeasonRows,
    stockLeaderRows,
    stockLatestEventRows,
    lotteryRoundRows,
    lotteryWinners,
  ] = await Promise.all([
    safeQuery(`
      SELECT
        p.id,
        p.title,
        p.content,
        p.created_at,
        u.nickname
      FROM community_main_posts mp
      INNER JOIN community_posts p ON p.id = mp.post_id
      LEFT JOIN users u ON u.id = p.user_id
      WHERE p.is_blind = 0
      ORDER BY mp.created_at DESC
      LIMIT 1
    `),

    safeQuery(`
      SELECT id, title
      FROM community_posts
      WHERE is_notice = 1
        AND is_blind = 0
      ORDER BY id DESC
      LIMIT 5
    `),

    safeQuery(`
      SELECT id, title
      FROM community_posts
      WHERE is_blind = 0
      ORDER BY id DESC
      LIMIT 5
    `),

    safeQuery(`
      SELECT id, title, likes
      FROM community_posts
      WHERE is_best = 1
        AND is_blind = 0
      ORDER BY likes DESC, id DESC
      LIMIT 5
    `),

    safeQuery(`
      SELECT c.id, c.content, c.post_id, u.nickname
      FROM community_comments c
      LEFT JOIN users u ON c.user_id = u.id
      ORDER BY c.id DESC
      LIMIT 5
    `),

    safeQuery(`
      SELECT id, item_name, item_image, price, item_type
      FROM shop_items
      WHERE is_active = 1
      ORDER BY id DESC
      LIMIT 6
    `),

    safeQuery(`
      SELECT id, nickname, dotori
      FROM users
      WHERE role != 'admin'
      ORDER BY dotori DESC
      LIMIT 5
    `),

    safeQuery(`
  SELECT
    s.*,
    p2.price AS prev_price
  FROM stock_items s
  LEFT JOIN stock_price_logs p1
    ON p1.stock_id = s.id
    AND p1.id = (
      SELECT MAX(id)
      FROM stock_price_logs
      WHERE stock_id = s.id
    )
  LEFT JOIN stock_price_logs p2
    ON p2.stock_id = s.id
    AND p2.id = (
      SELECT MAX(id)
      FROM stock_price_logs
      WHERE stock_id = s.id
        AND id < IFNULL(p1.id, 0)
    )
  ORDER BY s.is_listed DESC, s.current_price DESC
  LIMIT 5
`),

    safeQuery(`
      SELECT
        s.*,
        DATE_FORMAT(s.ends_at, '%Y-%m-%d %H:%i:%s') AS ends_at_text,
        (SELECT COUNT(*) FROM stock_season_participants p WHERE p.season_id = s.id) AS participant_count,
        (IFNULL(s.base_prize, 0) + IFNULL(s.entry_fee_prize, 0) + IFNULL(s.fee_prize, 0)) AS total_prize
      FROM stock_seasons s
      WHERE s.status IN ('ready', 'active')
      ORDER BY s.id DESC
      LIMIT 1
    `),

    safeQuery(`
      SELECT u.nickname, p.current_profit_rate
      FROM stock_season_participants p
      INNER JOIN users u ON u.id = p.user_id
      INNER JOIN stock_seasons s ON s.id = p.season_id
      WHERE s.status IN ('ready', 'active')
      ORDER BY p.current_profit_rate DESC, p.current_total_asset DESC, p.id ASC
      LIMIT 1
    `),

    safeQuery(`
      SELECT
        e.id,
        e.event_title,
        e.event_rate,
        DATE_FORMAT(e.created_at, '%Y.%m.%d %H:%i') AS created_at_text,
        si.stock_name
      FROM stock_events e
      INNER JOIN stock_items si ON si.id = e.stock_id
      WHERE e.event_type = 'up'
        AND EXISTS (
          SELECT 1
          FROM stock_seasons s
          WHERE s.status IN ('ready', 'active')
        )
      ORDER BY e.id DESC
      LIMIT 5
    `),

    safeQuery(`
  SELECT
      r.*,
      COUNT(e.id) AS participant_count

  FROM lottery_rounds r

  LEFT JOIN lottery_entries e
    ON e.round_id = r.id

  WHERE r.status='OPEN'

  GROUP BY r.id

  ORDER BY r.id DESC

  LIMIT 1
`),

    safeQuery(`
      SELECT nickname, rank_position, reward_amount
      FROM lottery_winners
      ORDER BY id DESC
      LIMIT 5
    `),
  ]);

  return {
    mainPost: mainPostRows[0] || null,
    noticePosts,
    recentPosts,
    bestPosts,
    recentComments,
    shopItems,
    dotoriRanking,
    stockPreview,
    stockSeasonCard: {
      season: stockSeasonRows[0] || null,
      leader: stockLeaderRows[0] || null,
      latestEvents: stockLatestEventRows || [],
    },
    lotteryPreview: {
      current: lotteryRoundRows[0] || null,
      winners: lotteryWinners,
    },
  };
}

export default async function Home() {
  const session = await getServerSession(authOptions);

  const [currentUser, video, siteSettings, mainData] = await Promise.all([
    getCurrentUser(session?.user?.email),
    getYoutubeVideo(),
    getSiteSettings(),
    getMainData(),
  ]);

  const isAdmin = currentUser?.role === "admin";
  const siteLogo = siteSettings.siteLogo;
  const isLiveOn = video?.isLive === true;
  const videos = Array.isArray(video?.videos) ? video.videos : [];
  const shorts = Array.isArray(video?.shorts)
    ? video.shorts.slice(0, 10)
    : videos.slice(0, 10);

  const {
    mainPost,
    noticePosts,
    recentPosts,
    bestPosts,
    recentComments,
    shopItems,
    dotoriRanking,
    stockPreview,
    stockSeasonCard,
    lotteryPreview,
  } = mainData;

  return (
    <main className="min-h-screen bg-[#05070d] text-white">
      <div className="fixed inset-0 -z-10 bg-[radial-gradient(circle_at_top,rgba(199,151,56,0.18),transparent_32%),linear-gradient(180deg,#070912,#03040a)]" />

      <header className="sticky top-0 z-50 border-b border-[#3b321f] bg-[#05070d]/95 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1500px] items-center justify-between gap-2 px-3 py-3 sm:px-4 lg:px-6 lg:py-4">
          <a href="/" className="flex items-center gap-3">
            {siteLogo ? (
              <img
                src={siteLogo}
                alt="왕츄 로고"
                loading="eager"
                decoding="async"
                className="h-9 max-w-[120px] object-contain sm:h-11 sm:max-w-[150px] lg:h-12 lg:max-w-[170px]"
              />
            ) : (
              <div>
                <p className="text-4xl font-black text-[#f7d36b]">왕츄</p>
                <p className="text-xs font-bold text-zinc-400">팬사이트 v1.0</p>
              </div>
            )}
          </a>

          <div className="ml-auto flex min-w-0 items-center gap-2 lg:ml-0">
            <NotificationBell />
          </div>

          <nav className="hidden items-center gap-7 text-sm font-black text-zinc-300 lg:flex">
            <a href="/" className="hover:text-[#f7d36b]">홈</a>

            <div className="group relative">
              <button className="hover:text-[#f7d36b]">게시판 ▾</button>
              <div className="invisible absolute left-0 top-8 w-52 rounded-2xl border border-[#3b321f] bg-[#0d1018] p-2 opacity-0 shadow-2xl transition-all group-hover:visible group-hover:opacity-100">
                <a href="/board/free?category=free" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">자유게시판</a>
                <a href="/board/free?category=notice" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">공지사항</a>
                <a href="/board/free?category=suggestion" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">건의사항</a>
                <a href="/board/free?category=from_wangchu" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">왕츄가 팬한테</a>
                <a href="/board/free?category=to_wangchu" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">팬이 왕츄한테</a>
                {currentUser && (
                  <a href="/board/my" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">내 활동</a>
                )}
              </div>
            </div>

            <div className="group relative">
              <button className="hover:text-[#f7d36b]">상점 ▾</button>
              <div className="invisible absolute left-0 top-8 w-56 rounded-2xl border border-[#3b321f] bg-[#0d1018] p-2 opacity-0 shadow-2xl transition-all group-hover:visible group-hover:opacity-100">
                <a href="/shop" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">전체 상점</a>
                {currentUser && <a href="/mypage/inventory" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">내 아이템</a>}
                {isAdmin && <a href="/admin/shop" className="block rounded-xl px-4 py-3 text-[#f7d36b] hover:bg-[#2b2415]">아이템 생성</a>}
              </div>
            </div>

            <div className="group relative">
              <button className="hover:text-[#f7d36b]">게임 ▾</button>
              <div className="invisible absolute left-0 top-8 w-56 rounded-2xl border border-[#3b321f] bg-[#0d1018] p-2 opacity-0 shadow-2xl transition-all group-hover:visible group-hover:opacity-100">
                <a href="/game" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">주사위 홀짝</a>
                <a href="/prediction" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">승패 예측</a>
                <a href="/game/ladder" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">사다리게임</a>
                <a href="/game/pinball" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">핀볼게임</a>
                <a href="/game/updown" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">업다운게임</a>
                <a href="/game/dog-race" className="block rounded-xl px-4 py-3 text-[#f7d36b] hover:bg-[#2b2415]">왈왈이경주</a>
                <a href="/lottery" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">도토리 로또</a>
              </div>
            </div>

            <a href="/stock" className="hover:text-[#f7d36b]">주식</a>

            {currentUser && (
              <div className="group relative">
                <button className="hover:text-[#f7d36b]">마이페이지 ▾</button>
                <div className="invisible absolute left-0 top-8 w-56 rounded-2xl border border-[#3b321f] bg-[#0d1018] p-2 opacity-0 shadow-2xl transition-all group-hover:visible group-hover:opacity-100">
                  <a href="/mypage" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">마이페이지</a>
                  <a href="/mypage/inventory" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">내 아이템</a>
                  <a href="/mypage/titles" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">칭호 변경</a>
                  <a href="/mypage/posts" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">내가 쓴 글</a>
                  <a href="/mypage/comments" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">내가 쓴 댓글</a>
                </div>
              </div>
            )}

            {isAdmin && (
              <div className="group relative">
                <button className="text-[#f7d36b] hover:text-white">관리자 ▾</button>
                <div className="invisible absolute right-0 top-8 w-60 rounded-2xl border border-[#3b321f] bg-[#0d1018] p-2 opacity-0 shadow-2xl transition-all group-hover:visible group-hover:opacity-100">
                  <a href="/admin" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">관리자 대시보드</a>
                  <a href="/admin/live-status" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">라이브 상태 관리</a>
                  <a href="/admin/shop" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">아이템 생성</a>
                  <a href="/admin/dotori" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">도토리 지급</a>
                  <a href="/admin/board" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">게시판 관리</a>
                  <a href="/admin/game" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">게임 관리</a>
                  <a href="/admin/dog-race" className="block rounded-xl px-4 py-3 hover:bg-[#2b2415]">왈왈이경주 관리</a>
                  <a href="/admin/lottery" className="block rounded-xl px-4 py-3 text-[#f7d36b] hover:bg-[#2b2415]">로또 관리</a>
                </div>
              </div>
            )}
          </nav>

          <div className="flex min-w-0 items-center gap-2 lg:gap-3">
            {currentUser && (
              <div className="hidden items-center gap-2 rounded-xl border border-[#3b321f] bg-[#0d1018] px-4 py-2 lg:flex">
                <span className="text-lg">🌰</span>
                <span className="whitespace-nowrap text-sm font-black text-white">
                  {Number(currentUser.dotori || 0).toLocaleString()}개
                </span>
              </div>
            )}

            <LoginButton />
          </div>
        </div>

        <div className="border-t border-white/5 lg:hidden">
          <nav className="mx-auto flex max-w-[1500px] gap-2 overflow-x-auto px-3 py-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            <a href="/" className="shrink-0 whitespace-nowrap rounded-xl bg-[#f7d36b] px-4 py-2 text-xs font-black text-black">홈</a>
            <a href="/board/free" className="shrink-0 whitespace-nowrap rounded-xl border border-white/10 bg-[#11131b] px-4 py-2 text-xs font-black text-white">게시판</a>
            <a href="/shop" className="shrink-0 whitespace-nowrap rounded-xl border border-white/10 bg-[#11131b] px-4 py-2 text-xs font-black text-white">상점</a>
            <a href="/game" className="shrink-0 whitespace-nowrap rounded-xl border border-white/10 bg-[#11131b] px-4 py-2 text-xs font-black text-white">게임</a>
            <a href="/stock" className="shrink-0 whitespace-nowrap rounded-xl border border-white/10 bg-[#11131b] px-4 py-2 text-xs font-black text-white">주식</a>
            <a href="/schedule" className="shrink-0 whitespace-nowrap rounded-xl border border-white/10 bg-[#11131b] px-4 py-2 text-xs font-black text-white">방송일정</a>
            {currentUser && (
              <a href="/mypage/inventory" className="shrink-0 whitespace-nowrap rounded-xl border border-white/10 bg-[#11131b] px-4 py-2 text-xs font-black text-white">내 아이템</a>
            )}
            {isAdmin && (
              <a href="/admin" className="shrink-0 whitespace-nowrap rounded-xl border border-[#f7d36b]/40 bg-[#2b2415] px-4 py-2 text-xs font-black text-[#f7d36b]">관리자</a>
            )}
          </nav>
        </div>
      </header>

      <div className="mx-auto max-w-[1500px] px-3 py-3 sm:px-4 sm:py-4 lg:px-5 lg:py-5">
        {mainPost && (
          <a
            href={`/board/free/${mainPost.id}`}
            className="group mb-4 block overflow-hidden rounded-2xl border border-amber-300/35 bg-[linear-gradient(135deg,rgba(247,211,107,.16),rgba(17,19,27,.98)_42%,rgba(126,34,206,.13))] p-4 shadow-[0_14px_40px_rgba(0,0,0,.28)] transition hover:border-amber-300/60 hover:-translate-y-0.5 sm:mb-5 sm:rounded-[26px] sm:p-5"
          >
            <div className="flex items-start gap-3 sm:gap-4">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-[#f7d36b] text-xl shadow-lg sm:h-12 sm:w-12">📌</div>
              <div className="min-w-0 flex-1">
                <div className="mb-1.5 flex flex-wrap items-center gap-2">
                  <span className="rounded-full bg-[#f7d36b] px-2.5 py-1 text-[10px] font-black text-black sm:text-xs">메인글</span>
                  {mainPost.nickname && <span className="text-xs font-bold text-zinc-400">{mainPost.nickname}</span>}
                </div>
                <h2 className="truncate text-lg font-black text-white group-hover:text-[#f7d36b] sm:text-2xl">{mainPost.title}</h2>
                <p className="mt-1 line-clamp-2 text-xs leading-5 text-zinc-400 sm:text-sm sm:leading-6">{mainPost.content}</p>
              </div>
              <span className="mt-2 shrink-0 text-xl font-black text-[#f7d36b] transition group-hover:translate-x-1">›</span>
            </div>
          </a>
        )}

        <section className="grid gap-5 xl:grid-cols-[1.05fr_0.9fr_360px]">
          <div className="rounded-2xl border border-[#3b321f] bg-[#090c14]/90 p-3 shadow-2xl sm:rounded-[26px] sm:p-5">
            <div className="mb-3 flex flex-wrap items-center gap-2 sm:mb-4">
              <h2 className="text-lg font-black text-[#f7d36b] sm:text-xl">왕츄 LIVE</h2>
              <span className={`rounded-md px-2 py-1 text-xs font-black ${isLiveOn ? "bg-red-600 text-white" : "bg-zinc-700 text-zinc-200"}`}>
                {isLiveOn ? "LIVE" : "OFF"}
              </span>

              <a
                href="https://www.youtube.com/@%EB%B0%95%EC%99%95%EC%B8%84"
                target="_blank"
                rel="noopener noreferrer"
                className="rounded-md bg-red-600 px-3 py-1 text-xs font-black text-white hover:bg-red-500"
              >
                라이브 보러가기
              </a>
            </div>

            <div className="space-y-5">
              <div className="mx-auto w-full max-w-[280px] overflow-hidden rounded-2xl border border-[#3b321f] bg-black sm:max-w-[340px] sm:rounded-3xl">
                <VideoPlayer videos={videos} />
              </div>

              <ShortsSlider videos={shorts} />
            </div>
          </div>

          <div className="space-y-5">
            <div className="rounded-2xl border border-[#3b321f] bg-[#090c14]/90 p-3 sm:rounded-[26px] sm:p-5">
              <h2 className="mb-4 text-xl font-black text-[#f7d36b]">바로가기</h2>
              <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 sm:gap-3 lg:grid-cols-6">
                <a href="/schedule" className="rounded-2xl border border-[#3b321f] bg-[#11131b] p-4 text-center hover:bg-[#2b2415]">
                  <div className="text-3xl">📅</div>
                  <div className="mt-2 text-xs font-black">방송일정</div>
                </a>

                <a href="/missions" className="rounded-2xl border border-[#3b321f] bg-[#11131b] p-4 text-center hover:bg-[#2b2415]">
                  <div className="text-3xl">📢</div>
                  <div className="mt-2 text-xs font-black">방송미션</div>
                </a>

                <a href="https://www.instagram.com/parkwangchu/" target="_blank" rel="noopener noreferrer" className="rounded-2xl border border-[#3b321f] bg-[#11131b] p-4 text-center hover:bg-[#2b2415]">
                  <div className="text-3xl">📸</div>
                  <div className="mt-2 text-xs font-black">인스타</div>
                </a>

                <a href="https://www.tiktok.com/@parkwangchu" target="_blank" rel="noopener noreferrer" className="rounded-2xl border border-[#3b321f] bg-[#11131b] p-4 text-center hover:bg-[#2b2415]">
                  <div className="text-3xl">🎵</div>
                  <div className="mt-2 text-xs font-black">틱톡</div>
                </a>

                <a href="https://toon.at/donate/wonywangchu" target="_blank" rel="noopener noreferrer" className="rounded-2xl border border-[#3b321f] bg-[#11131b] p-4 text-center hover:bg-[#2b2415]">
                  <div className="text-3xl">💰</div>
                  <div className="mt-2 text-xs font-black">투네이션</div>
                </a>

                <a href="/shop" className="rounded-2xl border border-[#3b321f] bg-[#11131b] p-4 text-center hover:bg-[#2b2415]">
                  <div className="text-3xl">🛒</div>
                  <div className="mt-2 text-xs font-black">상점</div>
                </a>

                <a href="/board/free" className="rounded-2xl border border-[#3b321f] bg-[#11131b] p-4 text-center hover:bg-[#2b2415]">
                  <div className="text-3xl">💬</div>
                  <div className="mt-2 text-xs font-black">게시판</div>
                </a>
              </div>
            </div>

            <div className="rounded-2xl border border-[#3b321f] bg-[#090c14]/90 p-3 sm:rounded-[26px] sm:p-5">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="text-xl font-black text-[#f7d36b]">출석 현황</h2>
                <span className="text-sm font-black text-[#f7d36b]">연속 출석</span>
              </div>
              <AttendanceButton />
              <DailyQuestCard userId={currentUser?.id || null} />
            </div>

            <div className="rounded-2xl border border-[#3b321f] bg-[#090c14]/90 p-3 sm:rounded-[26px] sm:p-5">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-xl font-black text-[#f7d36b]">게임 현황</h2>
                <a href="/game" className="text-xs text-zinc-400 hover:text-[#f7d36b]">
                  전체 게임 바로가기 〉
                </a>
              </div>

              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 sm:gap-3">
                <a href="/game" className="rounded-2xl border border-[#3b321f] bg-[#11131b] p-4 hover:bg-[#2b2415]">
                  <div className="text-4xl">🎲</div>
                  <p className="mt-3 font-black">주사위 홀짝</p>
                  <p className="text-xs text-zinc-500">게임하기</p>
                </a>

                <a href="/prediction" className="rounded-2xl border border-[#3b321f] bg-[#11131b] p-4 hover:bg-[#2b2415]">
                  <div className="text-4xl">📊</div>
                  <p className="mt-3 font-black">승패 예측</p>
                  <p className="text-xs text-zinc-500">예측하기</p>
                </a>

                <a href="/game/ladder" className="rounded-2xl border border-[#3b321f] bg-[#11131b] p-4 hover:bg-[#2b2415]">
                  <div className="text-4xl">🪜</div>
                  <p className="mt-3 font-black">사다리게임</p>
                  <p className="text-xs text-zinc-500">게임하기</p>
                </a>

                <a href="/game/pinball" className="rounded-2xl border border-[#3b321f] bg-[#11131b] p-4 hover:bg-[#2b2415]">
                  <div className="text-4xl">🕹️</div>
                  <p className="mt-3 font-black">핀볼</p>
                  <p className="text-xs text-zinc-500">게임하기</p>
                </a>

                <a href="/game/updown" className="rounded-2xl border border-[#3b321f] bg-[#11131b] p-4 hover:bg-[#2b2415]">
  <div className="text-4xl">🔼</div>
  <p className="mt-3 font-black">업다운게임</p>
  <p className="text-xs text-zinc-500">게임하기</p>
</a>

                <a href="/lottery" className="rounded-2xl border border-[#3b321f] bg-[#11131b] p-4 hover:bg-[#2b2415]">
                  <div className="text-4xl">🎟️</div>
                  <p className="mt-3 font-black">도토리 로또</p>
                  <p className="text-xs text-zinc-500">참여하기</p>
                </a>

                <a
                  href="/game/dog-race"
                  className="group relative overflow-hidden rounded-2xl border border-violet-500/35 bg-[radial-gradient(circle_at_top_right,rgba(168,85,247,.22),transparent_45%),#11131b] p-4 hover:border-violet-400 hover:bg-[#201735]"
                >
                  <div className="absolute right-2 top-2 rounded-full bg-red-500/15 px-2 py-1 text-[9px] font-black text-red-300">NEW</div>
                  <div className="text-4xl transition-transform group-hover:scale-110">🏁</div>
                  <p className="mt-3 font-black text-violet-200">왈왈이경주</p>
                  <p className="text-xs text-zinc-500">그랜드 더비 참가</p>
                </a>
              </div>
            </div>

            <BroadcastMissionCard isAdmin={isAdmin} />

            <div className="rounded-2xl border border-[#3b321f] bg-[#090c14]/90 p-3 sm:rounded-[26px] sm:p-5">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-xl font-black text-[#f7d36b]">🎟 도토리 로또</h2>

                <a href="/lottery" className="text-xs font-bold text-zinc-400 hover:text-[#f7d36b]">
                  참여하기 〉
                </a>
              </div>

              {lotteryPreview?.current ? (
                <>
                  <div className="grid gap-3 md:grid-cols-3">
                    <div className="rounded-2xl bg-[#151925] p-4">
                      <p className="text-sm text-zinc-400">현재 회차</p>
                      <p className="mt-1 text-xl font-black">
                        {lotteryPreview.current.round_number}회차
                      </p>
                    </div>

                    <div className="rounded-2xl bg-[#151925] p-4">
                      <p className="text-sm text-zinc-400">누적 상금</p>
                      <p className="mt-1 text-xl font-black text-yellow-300">
                        {Number(lotteryPreview.current.total_reward).toLocaleString()} 도토리
                      </p>
                    </div>

                    <div className="rounded-2xl bg-[#151925] p-4">
                      <p className="text-sm text-zinc-400">참여자</p>
                      <p className="mt-1 text-xl font-black">
                        {Number(lotteryPreview.current.participant_count)}명
                      </p>
                    </div>
                  </div>

                  <div className="mt-4 rounded-2xl bg-[#151925] p-4">
                    <p className="mb-2 text-sm font-black text-[#f7d36b]">최근 당첨자</p>

                    {lotteryPreview.winners.length === 0 ? (
                      <p className="text-sm text-zinc-400">아직 당첨 기록이 없습니다.</p>
                    ) : (
                      <div className="space-y-2">
                        {lotteryPreview.winners.map((winner: any, index: number) => (
                          <div key={index} className="text-sm text-zinc-300">
                            {winner.nickname} · {winner.rank_position}등 ·{" "}
                            <span className="font-black text-yellow-300">
                              {Number(winner.reward_amount).toLocaleString()}개
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </>
              ) : (
                <p className="text-sm text-zinc-400">진행 중인 로또가 없습니다.</p>
              )}
            </div>
          </div>

          <aside id="ranking" className="space-y-5">
            <GameRanking dotoriRanking={dotoriRanking} />

            <div className="rounded-2xl border border-[#3b321f] bg-[#090c14]/90 p-3 sm:rounded-[26px] sm:p-5">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-lg font-black text-[#f7d36b]">📈 주식 현황</h2>

                <a href="/stock" className="text-xs font-bold text-zinc-400 hover:text-[#f7d36b]">
                  전체 보기 〉
                </a>
              </div>

              {stockSeasonCard.season && (
                <a
                  href="/stock"
                  className="mb-4 block rounded-2xl border border-[#f7d36b]/35 bg-[linear-gradient(135deg,rgba(247,211,107,0.14),rgba(21,25,37,0.9))] p-4"
                >
                  <p className="text-xs font-black tracking-[0.16em] text-[#f7d36b]">진행 중인 주식 시즌</p>
                  <h3 className="mt-2 text-lg font-black">{stockSeasonCard.season.title}</h3>
                  <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                    <div className="rounded-xl bg-black/25 p-3">
                      <p className="text-zinc-500">현재 1등</p>
                      <p className="mt-1 truncate font-black">{stockSeasonCard.leader?.nickname || "아직 순위 없음"}</p>
                    </div>
                    <div className="rounded-xl bg-black/25 p-3">
                      <p className="text-zinc-500">1등 수익률</p>
                      <p className={`mt-1 font-black ${Number(stockSeasonCard.leader?.current_profit_rate || 0) >= 0 ? "text-red-400" : "text-blue-400"}`}>
                        {Number(stockSeasonCard.leader?.current_profit_rate || 0) >= 0 ? "+" : ""}{Number(stockSeasonCard.leader?.current_profit_rate || 0).toFixed(2)}%
                      </p>
                    </div>
                    <div className="rounded-xl bg-black/25 p-3">
                      <p className="text-zinc-500">총 상금</p>
                      <p className="mt-1 font-black text-yellow-300">{Number(stockSeasonCard.season.total_prize || 0).toLocaleString()} 도토리</p>
                    </div>
                    <div className="rounded-xl bg-black/25 p-3">
                      <p className="text-zinc-500">참가자</p>
                      <p className="mt-1 font-black">{Number(stockSeasonCard.season.participant_count || 0)}명</p>
                    </div>
                  </div>

                  <div className="mt-3 flex items-center justify-between rounded-xl border border-white/10 bg-black/20 px-3 py-2">
                    <span className="text-xs font-bold text-zinc-400">시즌 종료까지</span>
                    <span className="text-sm font-black text-white">{formatSeasonRemaining(stockSeasonCard.season.ends_at_text)}</span>
                  </div>

                  {stockSeasonCard.latestEvents.length > 0 && (
                    <div className="mt-3 overflow-hidden rounded-xl border border-red-400/20 bg-red-400/10">
                      <div className="border-b border-red-400/15 px-3 py-2 text-xs font-black text-red-200">🚨 최근 자동 호재</div>
                      <div className="divide-y divide-red-400/10">
                        {stockSeasonCard.latestEvents.map((event: any) => (
                          <div key={event.id} className="px-3 py-2">
                            <div className="flex items-center justify-between gap-2 text-xs">
                              <span className="min-w-0 truncate font-black text-red-100">{event.stock_name} · {event.event_title}</span>
                              <span className="shrink-0 font-black text-red-300">+{Number(event.event_rate || 0).toFixed(2)}%</span>
                            </div>
                            <p className="mt-1 text-[10px] text-red-200/60">{event.created_at_text}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  <p className="mt-3 text-right text-xs font-black text-[#f7d36b]">주식시장 참여하기 〉</p>
                </a>
              )}

              {stockPreview.length === 0 ? (
                <p className="text-sm text-zinc-400">등록된 주식이 없습니다.</p>
              ) : (
                <div className="space-y-3">
                  {stockPreview.map((stock: any) => {
                    const prev = Number(stock.prev_price || 0);
                    const stockCurrent = Number(stock.current_price || 0);
                    const diff = stockCurrent - prev;
                    const rate = prev > 0 ? Math.floor((diff / prev) * 100) : 0;

                    return (
                      <a
                        key={stock.id}
                        href={`/stock/${stock.id}`}
                        className="block rounded-2xl border border-[#2c2f3a] bg-[#151925] p-4 hover:border-[#f7d36b]/60"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-black">{stock.stock_name}</span>

                          {stock.is_listed ? (
                            <span className="text-xs text-emerald-400">상장중</span>
                          ) : (
                            <span className="text-xs text-red-400">상장폐지</span>
                          )}
                        </div>

                        <p className="mt-2 text-lg font-black text-[#f7d36b]">
                          {stockCurrent.toLocaleString()} 도토리
                        </p>

                        <p
                          className={`mt-1 text-sm font-bold ${
                            diff > 0
                              ? "text-red-400"
                              : diff < 0
                              ? "text-blue-400"
                              : "text-zinc-400"
                          }`}
                        >
                          {diff > 0 && "▲"}
                          {diff < 0 && "▼"}
                          {diff === 0
                            ? "변동 없음"
                            : `${Math.abs(diff).toLocaleString()} (${Math.abs(rate)}%)`}
                        </p>
                      </a>
                    );
                  })}
                </div>
              )}
            </div>
          </aside>
        </section>

        <section className="mt-5 grid gap-5 xl:grid-cols-[1fr_1.5fr]">
          <GameHighlights />

          <div className="rounded-3xl border border-[#3b321f] bg-[#0d1018] p-5">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-black text-[#f7d36b]">상점 추천 아이템</h2>
              <a href="/shop" className="text-xs font-bold text-zinc-400 hover:text-[#f7d36b]">
                전체 보기 〉
              </a>
            </div>

            {shopItems.length === 0 ? (
              <p className="rounded-2xl border border-[#2c2f3a] bg-[#151925] p-5 text-sm text-zinc-400">
                등록된 상점 아이템이 없습니다.
              </p>
            ) : (
              <div className="grid grid-cols-2 gap-3 md:grid-cols-6">
                {shopItems.map((item: any) => (
                  <a
                    key={item.id}
                    href="/shop"
                    className="rounded-2xl border border-[#2c2f3a] bg-[#151925] p-3 text-center hover:border-[#f7d36b]/60"
                  >
                    <div className="flex h-24 items-center justify-center overflow-hidden rounded-xl bg-black/25">
                      {item.item_image ? (
                        <img
                          src={item.item_image}
                          alt={item.item_name}
                          loading="lazy"
                          decoding="async"
                          className="h-full w-full object-contain"
                        />
                      ) : (
                        <span className="text-4xl">🎁</span>
                      )}
                    </div>
                    <p className="mt-3 truncate text-sm font-black">{item.item_name}</p>
                    <p className="mt-1 text-sm font-black text-[#f7d36b]">
                      🌰 {Number(item.price).toLocaleString()}
                    </p>
                  </a>
                ))}
              </div>
            )}
          </div>
        </section>

        <section id="notice" className="mt-5 grid gap-5 lg:grid-cols-5">
          <div className="rounded-3xl border border-[#3b321f] bg-[#0d1018] p-5">
            <h2 className="mb-4 text-lg font-black text-[#f7d36b]">공지사항</h2>
            <div className="space-y-3">
              {noticePosts.length > 0 ? (
                noticePosts.map((post: any) => (
                  <a key={post.id} href={`/board/free/${post.id}`} className="block truncate text-sm text-zinc-300 hover:text-[#f7d36b]">
                    📌 {post.title}
                  </a>
                ))
              ) : (
                <p className="text-sm text-zinc-400">아직 공지가 없습니다.</p>
              )}
            </div>
          </div>

          <div className="rounded-3xl border border-[#3b321f] bg-[#0d1018] p-5">
            <h2 className="mb-4 text-lg font-black text-[#f7d36b]">인기글</h2>
            <div className="space-y-3">
              {bestPosts.length > 0 ? (
                bestPosts.map((post: any, index: number) => (
                  <a key={post.id} href={`/board/free/${post.id}`} className="flex items-center justify-between gap-2 text-sm text-zinc-300 hover:text-[#f7d36b]">
                    <span className="truncate">{index + 1}. {post.title}</span>
                    <span className="text-[#f7d36b]">👍 {post.likes}</span>
                  </a>
                ))
              ) : (
                <p className="text-sm text-zinc-400">인기글이 없습니다.</p>
              )}
            </div>
          </div>

          <div className="rounded-3xl border border-[#3b321f] bg-[#0d1018] p-5">
            <h2 className="mb-4 text-lg font-black text-[#f7d36b]">최근 게시글</h2>
            <div className="space-y-3">
              {recentPosts.length > 0 ? (
                recentPosts.map((post: any) => (
                  <a key={post.id} href={`/board/free/${post.id}`} className="block truncate text-sm text-zinc-300 hover:text-[#f7d36b]">
                    {post.title}
                  </a>
                ))
              ) : (
                <p className="text-sm text-zinc-400">게시글이 없습니다.</p>
              )}
            </div>
          </div>

          <div className="rounded-3xl border border-[#3b321f] bg-[#0d1018] p-5">
            <h2 className="mb-4 text-lg font-black text-[#f7d36b]">최근 댓글</h2>
            <div className="space-y-3">
              {recentComments.length > 0 ? (
                recentComments.map((comment: any) => (
                  <a key={comment.id} href={`/board/free/${comment.post_id}`} className="block text-sm text-zinc-300 hover:text-[#f7d36b]">
                    <p className="truncate">{comment.content}</p>
                    <p className="mt-1 text-xs text-zinc-500">{comment.nickname || "익명"}</p>
                  </a>
                ))
              ) : (
                <p className="text-sm text-zinc-400">최근 댓글이 없습니다.</p>
              )}
            </div>
          </div>

          <div className="rounded-3xl border border-[#3b321f] bg-[#0d1018] p-5">
            <h2 className="mb-4 text-lg font-black text-[#f7d36b]">내 활동</h2>
            {currentUser ? (
              <div className="space-y-3 text-sm">
                <a href="/mypage/posts" className="flex justify-between rounded-xl bg-[#151925] px-4 py-3 hover:bg-[#2b2415]">
                  <span>내가 쓴 글</span>
                  <span className="text-[#f7d36b]">보기</span>
                </a>
                <a href="/mypage/comments" className="flex justify-between rounded-xl bg-[#151925] px-4 py-3 hover:bg-[#2b2415]">
                  <span>내가 쓴 댓글</span>
                  <span className="text-[#f7d36b]">보기</span>
                </a>
                <a href="/mypage/inventory" className="flex justify-between rounded-xl bg-[#151925] px-4 py-3 hover:bg-[#2b2415]">
                  <span>보유 아이템</span>
                  <span className="text-[#f7d36b]">보기</span>
                </a>
                <a href="/mypage/titles" className="flex justify-between rounded-xl bg-[#151925] px-4 py-3 hover:bg-[#2b2415]">
                  <span>칭호 변경</span>
                  <span className="text-[#f7d36b]">보기</span>
                </a>
              </div>
            ) : (
              <p className="text-sm text-zinc-400">로그인하면 내 활동을 확인할 수 있습니다.</p>
            )}
          </div>
        </section>
      </div>
    </main>
  );
}